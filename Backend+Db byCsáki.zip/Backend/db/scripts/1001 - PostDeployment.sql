﻿INSERT INTO
	User
	(UniqID, Email, Jelszo, Role)
VALUES
  ('be5d0cd7-c121-4d29-b939-3cadd483be4e', 'wasyster@gmail.com', 'password', 'ROLE_ADMIN'),
  ('1e735fd6-5032-43b8-848c-c1a3de40b8d8', 'elsoegon@test.com', 'password1', 'ROLE_CLIENT'),
  ('da893cb2-f8c7-4a0d-a4b5-8d0543c68867', 'masodikmiksa@test.com', 'password2', 'ROLE_CLIENT'),
  ('a52e9283-793c-41ec-b057-c24b256ed22e', 'harmadikhuba@test.com', 'password3', 'ROLE_CLIENT'),
  ('12785bfc-fbef-4256-8118-8ebd2179d2d3', 'negyediknero@test.com', 'password4', 'ROLE_CLIENT'),
  ('d89ecc28-01a0-47eb-8aea-8d5f830f5eed', 'otodikodon@test.com', 'password5', 'ROLE_CLIENT'),
  ('fa2149af-4662-4089-b8de-63402efeb8c9', 'hatodikhanibal@test.com', 'password6', 'ROLE_CLIENT'),
  ('fa8e4ae6-5f54-4640-8f91-71c49a61b3a7', 'hetedikheraclius@test.com', 'password7', 'ROLE_CLIENT');


INSERT INTO
	Diak
	(UniqID, Nev, Kreditek)
VALUES
  ('1e735fd6-5032-43b8-848c-c1a3de40b8d8', 'Első Egon', 52),
  ('da893cb2-f8c7-4a0d-a4b5-8d0543c68867', 'Második Miksa', 25),
  ('a52e9283-793c-41ec-b057-c24b256ed22e', 'Harmadik Huba', 10),
  ('12785bfc-fbef-4256-8118-8ebd2179d2d3', 'Negyedik Néró', 89),
  ('d89ecc28-01a0-47eb-8aea-8d5f830f5eed', 'Ötödik Ödön', 69),
  ('fa2149af-4662-4089-b8de-63402efeb8c9', 'Hatodik Hanibál', 89),
  ('fa8e4ae6-5f54-4640-8f91-71c49a61b3a7', 'Hetedik Heraclius', 39);
