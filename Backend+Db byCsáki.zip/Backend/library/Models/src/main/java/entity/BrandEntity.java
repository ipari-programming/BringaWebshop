package entity;

public class BrandEntity {
    public int Id;
    public String Name;

    public BrandEntity()
    {
    }

    public BrandEntity(int id, String name)
    {
        Id = id;
        Name = name;
    }
}
