package entity;

public class ShifterEntity {
    public int Id;
    public String Name;

    public ShifterEntity() {
    }

    public ShifterEntity(int id, String name) {
        Id = id;
        Name = name;
    }
}
