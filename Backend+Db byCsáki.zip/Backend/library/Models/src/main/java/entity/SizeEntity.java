package entity;

public class SizeEntity {
    public int Id;
    public String Name;

    public SizeEntity() {
    }

    public SizeEntity(int id, String name) {
        Id = id;
        Name = name;
    }
}
