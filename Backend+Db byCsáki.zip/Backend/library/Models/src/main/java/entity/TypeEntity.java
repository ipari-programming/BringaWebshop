package entity;

public class TypeEntity {
    public int Id;
    public String Name;

    public TypeEntity() {
    }

    public TypeEntity(int id, String name) {
        Id = id;
        Name = name;
    }


}
