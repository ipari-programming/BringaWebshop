package entity;

public class WheelDiameterEntity {
    public int Id;
    public String Name;

    public WheelDiameterEntity() {
    }

    public WheelDiameterEntity(int id, String name) {
        Id = id;
        Name = name;
    }

}
