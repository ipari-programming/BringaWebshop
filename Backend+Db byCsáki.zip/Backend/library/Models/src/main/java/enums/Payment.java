package enums;

public enum Payment {
    PAYMENT_CASH,
    PAYMENT_DEBITCARD,
    PAYMENT_TRANSFER;
}
