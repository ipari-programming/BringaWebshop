export interface IErrors
{
    /* The validation error messages for each field (key is the field name */
    [key: string]: string;
}