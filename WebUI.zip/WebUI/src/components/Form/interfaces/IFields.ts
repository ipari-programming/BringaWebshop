import { IFieldProps } from "./IFieldProps";

export interface IFields
{
    [key: string]: IFieldProps;
}