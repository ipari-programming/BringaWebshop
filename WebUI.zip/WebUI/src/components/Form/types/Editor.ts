/* The available editors for the field */
export type Editor = "textbox" |
                     "multilinetextbox" |
                     "dropdown" |
                     "radio" |
                     "checkbox" |
                     "date" |
                     "image";