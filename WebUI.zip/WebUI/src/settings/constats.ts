export module StorageKeys
{
    export const JWT: string = "JWT";
}