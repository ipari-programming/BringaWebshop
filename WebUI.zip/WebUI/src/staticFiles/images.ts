export module LocalImages
{
    export const images = require.context("./../assets/images", true);
}