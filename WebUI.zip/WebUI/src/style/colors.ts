export module CustomColors
{
    export const background = "#000";
    export const font = "#ceb95e";
    export const darkerFont = "#716b50";
    export const borderColor = "#847846";
}