export default interface StringMap
{
    [key: string]: string;
}